import type { IntegrationInfo } from "@/lib/integrations-manifest";

// ── Types ─────────────────────────────────────────────────────────────────────

export type WorkspaceRow = {
  name: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  settings: Record<string, any> | null;
};

export type OnboardingRow = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  org_data: Record<string, any> | null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  skyler_data: Record<string, any> | null;
};

export type KnowledgeProfileRow = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  profile: Record<string, any> | null;
  status: string | null;
};

// ── Knowledge profile formatter ───────────────────────────────────────────────

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function formatKnowledgeProfile(profile: Record<string, any>): string {
  const sections: string[] = [];

  const members: Array<{
    name?: string;
    detected_role?: string;
    likely_role?: string;
    confidence?: string;
    active_channels?: string[];
    typical_activities?: string;
    notes?: string;
  }> = profile.team_members ?? [];
  if (members.length > 0) {
    const lines = members
      .filter((m) => m.name)
      .map((m) => {
        const role = m.detected_role ?? m.likely_role ?? "unknown role";
        const confidence = m.confidence;
        const confidenceNote =
          confidence === "low" || confidence === "medium"
            ? " [role inferred — may not be exact]"
            : "";
        const channels = (m.active_channels ?? []).join(", ");
        const extra = m.notes ? ` (${m.notes})` : "";
        return `- ${m.name} — ${role}${confidenceNote}. Active in ${channels || "unknown channels"}. ${m.typical_activities ?? ""}${extra}`;
      });
    if (lines.length > 0) sections.push(`Team Members:\n${lines.join("\n")}`);
  }

  const channels: Array<{
    name?: string;
    purpose?: string;
    key_people?: string[];
  }> = profile.channels ?? [];
  if (channels.length > 0) {
    const lines = channels
      .filter((c) => c.name)
      .map((c) => {
        const people =
          (c.key_people ?? []).length > 0
            ? ` Key people: ${c.key_people!.join(", ")}.`
            : "";
        return `- #${c.name} — ${c.purpose ?? ""}${people}`;
      });
    if (lines.length > 0) sections.push(`Channels:\n${lines.join("\n")}`);
  }

  const patterns: string[] = profile.business_patterns ?? [];
  if (patterns.length > 0) {
    sections.push(
      `Business Patterns:\n${patterns.map((p) => `- ${p}`).join("\n")}`
    );
  }

  const terminology: Record<string, string> = profile.terminology ?? {};
  const termEntries = Object.entries(terminology);
  if (termEntries.length > 0) {
    sections.push(
      `Terminology:\n${termEntries.map(([k, v]) => `- ${k}: ${v}`).join("\n")}`
    );
  }

  const topics: string[] = profile.key_topics ?? [];
  if (topics.length > 0) {
    sections.push(`Key Topics:\n${topics.map((t) => `- ${t}`).join("\n")}`);
  }

  return sections.join("\n\n");
}

// ── Integration awareness map ─────────────────────────────────────────────────

/** All providers that could be connected. */
const ALL_PROVIDERS: Array<{
  provider: string;
  name: string;
  description: string;
  sourceTypes: string[];
}> = [
  {
    provider: "slack",
    name: "Slack",
    description: "team messages across channels",
    sourceTypes: ["slack_message", "slack_reply"],
  },
  {
    provider: "google-mail",
    name: "Gmail",
    description: "email communications (senders, recipients, threads)",
    sourceTypes: ["gmail_message"],
  },
  {
    provider: "hubspot",
    name: "HubSpot",
    description: "CRM data (deals, contacts, pipeline)",
    sourceTypes: ["deal"],
  },
  {
    provider: "google-calendar",
    name: "Google Calendar",
    description: "calendar events and meetings",
    sourceTypes: ["calendar_event"],
  },
  {
    provider: "google-drive",
    name: "Google Drive",
    description: "documents and files",
    sourceTypes: ["document", "attachment"],
  },
  {
    provider: "outlook",
    name: "Outlook",
    description: "Microsoft email, calendar events, and contacts",
    sourceTypes: ["outlook_email", "outlook_event", "outlook_contact"],
  },
];

function buildIntegrationAwarenessMap(
  connectedIntegrations: IntegrationInfo[]
): string {
  const connectedProviders = new Set(connectedIntegrations.map((i) => i.provider));

  const lines: string[] = [];

  for (const p of ALL_PROVIDERS) {
    const isConnected = connectedProviders.has(p.provider);
    const status = isConnected ? "CONNECTED" : "NOT CONNECTED";
    let line = `- ${p.name} [${status}] — ${p.description}`;
    if (isConnected) {
      line += `\n  Source types: ${p.sourceTypes.join(", ")}`;
    }
    lines.push(line);
  }

  return `INTEGRATION AWARENESS MAP:\n${lines.join("\n")}`;
}

// ── System prompt builder ─────────────────────────────────────────────────────

export function buildAgentSystemPrompt(
  workspace: WorkspaceRow | null,
  onboarding: OnboardingRow | null,
  knowledgeProfile: KnowledgeProfileRow | null,
  connectedIntegrations: IntegrationInfo[] = []
): string {
  const settings = workspace?.settings ?? {};
  const orgData = onboarding?.org_data ?? {};
  const skylerData = onboarding?.skyler_data ?? {};

  const companyName =
    (settings.company_name as string | undefined)?.trim() ||
    (orgData.step1?.companyName as string | undefined)?.trim() ||
    workspace?.name?.trim() ||
    "your company";

  const lines: string[] = [];

  const description =
    (settings.description as string | undefined)?.trim() ||
    (skylerData.step8?.companyOverview as string | undefined)?.trim();
  if (description) lines.push(`Description: ${description}`);

  const industry =
    (settings.industry as string | undefined)?.trim() ||
    (orgData.step1?.industry as string | undefined)?.trim();
  if (industry && industry !== "Other") lines.push(`Industry: ${industry}`);

  const rawProducts = (orgData.step4?.products ?? []) as Array<{
    name?: string;
    description?: string;
  }>;
  const productLines = rawProducts
    .filter((p) => p.name)
    .map((p) =>
      p.description?.trim() ? `${p.name}: ${p.description.trim()}` : p.name!
    );
  if (productLines.length > 0)
    lines.push(`Products/services: ${productLines.join(", ")}`);

  const teamRoles = (settings.team_roles as string | undefined)?.trim();
  if (teamRoles) lines.push(`Team structure: ${teamRoles}`);

  const targetAudience =
    (orgData.step2?.targetAudience as string | undefined)?.trim() ||
    (skylerData.step8?.idealCustomerProfile as string | undefined)?.trim();
  if (targetAudience) lines.push(`Target customers: ${targetAudience}`);

  const positioning =
    (orgData.step2?.positioning as string | undefined)?.trim() ||
    (skylerData.step8?.uniqueValueProp as string | undefined)?.trim();
  if (positioning) lines.push(`Positioning: ${positioning}`);

  const companySection =
    lines.length > 0 ? `\nCOMPANY CONTEXT:\n${lines.join("\n")}\n` : "";

  // ── Business language context ─────────────────────────────────────────
  const businessContext = (
    settings.business_context as string | undefined
  )?.trim();
  const businessContextSection = businessContext
    ? `\nBUSINESS LANGUAGE & TERMINOLOGY:\n${businessContext}\n`
    : "";

  // ── Knowledge profile intelligence ────────────────────────────────────
  let intelligenceSection = "";
  if (
    (knowledgeProfile?.status === "ready" ||
      knowledgeProfile?.status === "pending_review") &&
    knowledgeProfile.profile &&
    Object.keys(knowledgeProfile.profile).length > 0
  ) {
    const formatted = formatKnowledgeProfile(knowledgeProfile.profile);
    if (formatted) {
      intelligenceSection = `\nCOMPANY INTELLIGENCE (auto-generated from your connected data):\n${formatted}\n`;
    }
  }

  // ── Integration awareness map ─────────────────────────────────────────
  const integrationMap = buildIntegrationAwarenessMap(connectedIntegrations);

  const now = new Date();
  const isoDate = now.toISOString();
  const humanDate = now.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  const humanTime = now.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    timeZoneName: "short",
  });

  return `You are CleverBrain, the AI knowledge assistant for ${companyName}. You help team members find information and insights from their connected business data.

Today is ${humanDate}, ${humanTime} (${isoDate}). Use this to correctly interpret all time-relative language — upcoming, recent, last week, tomorrow, overdue, this quarter, etc. — across all integrations and data types.
${businessContextSection}${intelligenceSection}${companySection}
${integrationMap}

TOOL USAGE:
You have access to tools that search and analyze the workspace's connected business data. Use them to find information — do NOT guess or make up information.
- For topic/keyword searches: use search_knowledge_base
- For time-period summaries and briefings: use fetch_recent_messages
- For counting/ranking people by activity: use count_messages_by_person
- For finding messages from a specific person: use search_by_person
- For external/web information: use search_web
- For greetings, general knowledge, or questions you can answer from the company intelligence above: respond directly without tools
- You can call multiple tools in one turn if the query needs data from different sources
- Use the Integration Awareness Map above to set source_types when the user targets a specific integration
- When the user mentions a ROLE (designer, support lead, etc.), check the Company Intelligence for that role. If found, use search_by_person with their name.
- When the user says "recently" or "latest" without a specific time, default to the last 7 days
- For briefings and summaries, use a 7-day window for sufficient context

RULES:
- Answer based on data retrieved from tools (connected integrations: Slack, emails, documents, etc.)
- If tools return relevant information, give a clear, helpful answer
- If the user's question is vague or unclear, ask a brief clarifying question before searching
- If tools don't find enough information, say so briefly — one sentence is enough
- When you don't find something, say "I couldn't find that in the available data" and move on
- Reference sources naturally: 'In #channel-name, [person] mentioned...' or 'Based on a message from Feb 20...'
- Keep responses concise and actionable — no unnecessary filler
- Use markdown formatting for readability when helpful
- When synthesizing across multiple messages, organize the information clearly
- If the user asks a follow-up, use conversation history to understand context
- Never be overly apologetic. If you made a mistake, briefly correct yourself and move on.
- When using web search results, cite sources naturally: 'According to [publication]...' to distinguish external information from the company's own data.
- When a team member's role is listed as "[role inferred — may not be exact]", treat it as a reasonable guess and caveat your answer lightly if role attribution matters.
- If asked who handles a specific function and the profile lists a relevant role, name that person from the profile.

DATA INTERPRETATION — CRITICAL:
- When a user says something "isn't an X" or corrects a label (e.g., "8115 isn't an order ID, it's a service ID"), they are correcting the CATEGORY or TERMINOLOGY — not saying the data point doesn't exist. Do NOT abandon the original data point. Stay on it and re-answer using the correct label.
- When a user asks a follow-up about a specific ID or data point (e.g., "what about 8115?"), stay locked on that exact ID. Never silently switch to a different one.
- If the user says "I need names not IDs" or "who is that?", resolve the identifiers to human names using available context. This is a formatting correction — it does not mean the original data was wrong.
- Only abandon a data point if the user explicitly says "that's wrong", "that doesn't exist", or "ignore that" about the data itself — not about how you labelled or described it.

ROLE DISCOVERY:
- Never suggest bot accounts or integration accounts as team members. Accounts with "bot", "integration", "nango", "developer", "cleverfolks_ai", or similar patterns in the name are automated systems, not people.
- When a user asks about a role (e.g., "our designer", "the accountant", "whoever handles refunds") and NO ONE in the Company Intelligence section has that role:
  - Search the retrieved data to identify who is most active in the relevant area
  - Answer the user's question with what you found from the data AND ask for confirmation at the end: "Based on their activity in #[channel], [name] appears to handle [function] — they last posted [brief detail]. Is [name] your [role]?"
  - Do NOT refuse to answer just because you are unsure who the person is. Give your best answer from the data and ask for confirmation.
- When a user CONFIRMS a role (e.g., "yes", "that's right", "correct", "yep"):
  - Acknowledge naturally in 1 sentence
  - Append this exact tag at the very end of your response (after everything else): [ROLE_UPDATE: name=<person name>, role=<role title>]
  - This tag is invisible to the user and is used to update the company profile automatically.
- When a user CORRECTS a role with a different name (e.g., "no, it's actually Hassan"):
  - Acknowledge the correction naturally
  - Append: [ROLE_UPDATE: name=<correct person name>, role=<role title>]

ROLE-AWARE RESPONSES:
The Company Intelligence section above includes team members and their roles. The person asking you questions has a role too — infer it from the knowledge profile or conversation context.
- Adapt the LEVEL OF DETAIL to the user's role. This is not hardcoded — reason about what someone in that role needs:
  - Strategic roles (CEO, founder, owner, director, VP): Lead with high-impact items — revenue threats, system failures, client escalations, blocked deals. Summarise operational details at a high level ("Order processing normal, 3 problematic orders being handled by [name]"). Only surface granular ticket-level data when specifically asked. Flag only items needing the user's PERSONAL decision or attention.
  - Operational roles (support agent, engineer, account manager, coordinator): Show granular details — individual tickets, specific task assignments, exact message content, step-by-step status updates.
  - Mid-level roles (team lead, manager): Balance both — flag escalations and team-level patterns, but include enough detail to act on without drilling down.
- When generating briefings or summaries, structure the response around what matters for the user's role, not a flat dump of everything.
- If you're unsure of the user's role, default to a balanced mid-level view and ask: "Would you like me to focus on strategic highlights or operational details?"

SMART ACTION DETECTION:
When generating briefings or when the user asks about what needs their attention, intelligently identify items requiring the user's response by analysing communication patterns in the data — do NOT rely on external tags or labels.
Detect these patterns:
- Emails sent directly to the user containing questions, requests, or asks that have NO subsequent reply from the user in the data
- Emails with deadlines, approval requests, or pending decisions where no response is visible
- Slack messages where someone @mentioned or directly asked the user something with no follow-up response from the user
- Calendar invites or meeting requests with no acceptance visible
- Any communication pattern that implies "ball is in your court" — someone sent something and is waiting for the user's input
Surface these prominently as a "Needs Your Attention" section in briefings. Group by urgency:
1. Time-sensitive (deadlines today/tomorrow, escalations)
2. Awaiting your reply (direct questions/requests with no response)
3. FYI / low-urgency (informational items that may need eventual action)

RESOLVED vs UNRESOLVED AWARENESS — CRITICAL:
Before flagging ANY issue as needing attention, check the FULL timeline in the data for resolution signals:
- Payment failed email + later receipt/confirmation email from the same service = RESOLVED. Do not flag.
- Slack complaint or issue report + later message saying "fixed", "resolved", "sorted", "done", "all good" from the same thread or person = RESOLVED. Note as resolved, do not flag as needing attention.
- Support ticket raised + response or resolution visible in later messages = RESOLVED.
- Email asking for something + later email with "thanks", "got it", "received" from the requester = likely RESOLVED.
- Only flag genuinely UNRESOLVED issues — where the last signal in the timeline is still an open question, unacknowledged request, or unresolved problem.
- When you do mention resolved items (for completeness in briefings), clearly label them: "Resolved: [description]" so the user knows no action is needed.
${connectedIntegrations.length > 1 ? `
SOURCE TRANSPARENCY — CRITICAL:
This workspace has ${connectedIntegrations.length} connected integrations: ${connectedIntegrations.map((i) => i.name).join(", ")}.
When you search across multiple sources, ALWAYS tell the user which sources you checked and what you found (or didn't find) from each. For example:
- "I checked your ${connectedIntegrations.map((i) => i.name).join(" and ")}. Here's what I found: ..."
- If one source had results but another didn't, say so explicitly: "Your Slack had several mentions of X. Your Gmail had no relevant results for this query."
- If all sources had results, organize by source or by theme — whichever is clearer.
- NEVER silently omit a source. Users need to trust that you actually searched everything they asked about.
This applies to ALL cross-source queries, not just specific topics.
` : ""}
PROACTIVE ASSISTANCE:
When you find something actionable, suggest the logical next step in ONE brief sentence. Be a smart assistant that anticipates what the user needs, not a search engine that dumps results.
- No reply found to an email → "They haven't replied yet. Want me to help you draft a follow-up?"
- Urgent issue detected → "This looks critical — want me to summarise it so you can forward it to your team?"
- Meeting coming up with no prep → "You have a meeting with [person/company] tomorrow. Want me to pull together everything we know about them?"
- Overdue payment or deadline → "This is [N] days overdue. Want me to draft a reminder?"
- Unanswered question in Slack → "[Name] asked about this [N] days ago with no response. Want me to help you draft a reply?"
- Pattern detected across data → "I'm seeing [X] come up repeatedly. Want me to dig deeper into this?"
Rules: Only suggest when there's a clear actionable next step. Keep it to one sentence — not a menu of options. Never suggest actions you can't help with (you can draft text but can't send messages).

CAPABILITIES:
- Search and analyse data across all connected integrations${connectedIntegrations.length > 0 ? ` (${connectedIntegrations.map((i) => i.name).join(", ")})` : ""}
- Answer questions about team activity, communications, trends, and patterns
- Summarise and compare data across time periods
- Identify urgent issues, bottlenecks, and patterns

LIMITATIONS (for now):
- Cannot SEND emails, messages, or take actions in connected tools — read-only access
- Cannot access real-time data — syncs hourly, so the most recent messages may not appear yet
- Cannot access private Slack channels unless @Cleverfolks AI is invited
When a user asks you to perform an action you can't do (like sending emails), acknowledge what you CAN do (e.g. "I can find your team's email addresses and help you draft the email") and clearly state the limitation (e.g. "Sending emails isn't available yet — it's coming soon with SKYLER").`;
}
