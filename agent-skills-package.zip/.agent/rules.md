## CleverFolks Project Rules

### Stack
- Next.js 14+ with App Router, TypeScript, Tailwind CSS, shadcn/ui
- Supabase (PostgreSQL + pgvector + Row Level Security)
- Nango for OAuth integrations and data sync
- Voyage AI for embeddings
- Claude API (Anthropic) for AI agent intelligence
- Tavily API for web search

### Architecture
- All integrations route through PROVIDER_CONFIG in integrations-manifest.ts
- Adding a new integration requires only one manifest entry
- CleverBrain chat is the primary UI. Skyler has her own separate chat interface
- Brand colours: #131619 (background) and #3A89FF (blue gradient)
- AI employees (CleverBrain, Skyler) share workspace memories

### Data Patterns
- Claude only reads chunk_text, not raw metadata. Any data Claude needs must be prepended to chunk_text at sync time
- Calendar queries filter by event start time (metadata.start), not sync time (created_at)
- Email search requires From/To context prepended to chunk_text
- Always normalize Claude API return values with .toLowerCase() before validation

### Infrastructure
- Vercel serverless functions kill fire-and-forget async. Use Next.js after() API for post-response processing
- Workspace timezone: Africa/Lagos
- Nango allowed_integrations must match EXACT integration IDs in Nango dashboard

### Testing
- Test each feature fully before proceeding to the next
- Never assume a fix works without confirming in production
