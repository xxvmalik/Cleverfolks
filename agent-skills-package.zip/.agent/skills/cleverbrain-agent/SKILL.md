---
name: cleverbrain-agent
description: Use when working on CleverBrain's AI chat, agent loop, system prompt, tool definitions, query planning, or response generation.
---

# CleverBrain Agent Loop

## How It Works
1. User sends message via chat
2. Last 5 messages passed to planner for context
3. Planner detects intent and routes to appropriate tools
4. Tools: semantic search, broad fetch, time-range query, web search, calendar, knowledge profile
5. Results aggregated and passed to Claude for response generation
6. Memory extracted post-response via Next.js after() API

## Intelligence Principles
- Lead with the answer, match response length to complexity
- Web search is mandatory with regional context (Nigeria/Africa for TheKclaut)
- Proactive suggestions mandatory for 5 trigger patterns
- Source narration should be brief and natural, not verbose
- If memory FULLY answers the question, respond from memory only, no tool calls

## Memory System
- workspace_memories table with pgvector similarity search
- memory-extractor.ts: Claude extracts learnings post-conversation
- memory-store.ts: save/retrieve with conflict resolution (add, reinforce, supersede, skip)
- Always .toLowerCase() on Claude returned type values
- Uses Next.js after() API to survive Vercel serverless termination

## Key Patterns
- Integration-agnostic routing via PROVIDER_CONFIG manifest
- Broad fetch scales dynamically by connected integration count
- Planner receives last 5 messages for pronoun resolution
- Aggregation safeguard preserves source_types filter through all search paths
